recipes = {
    "Butter chicken": {"potato": 5, "oil": 10},
    "Chicken and chips": {"k": 6, "l": 8, "oil": 2},
    "Pizza": {"veg": 9, "Non-veg": 10}
}
pantry = {
    "potato": 25,
    "oil": 1,
    "k": 20,
    "veg": 12,
    "Non-veg": 15,
}
